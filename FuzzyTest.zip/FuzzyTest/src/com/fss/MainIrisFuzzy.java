package com.fss;

import fuzzlib.FuzzySet;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainIrisFuzzy {

    // Dane wejściowe: kontenery na atrybuty i nazwy gatunków
    private static final List<double[]> dataSamples = new ArrayList<>();
    private static final List<String> dataLabels = new ArrayList<>();

    // Definicje gatunków irysów występujących w pliku
    private static final String[] IRIS_TYPES = {
            "Iris-setosa",
            "Iris-versicolor",
            "Iris-virginica"
    };

    // Macierze przechowujące parametry rozkładu (4 cechy x 3 klasy)
    private static double[][] avgMatrix = new double[4][3];
    private static double[][] deviationMatrix = new double[4][3];

    public static void main(String[] args) {
        // 1. Inicjalizacja danych z pliku zewnętrznego
        if (!readData("iris.data")) {
            System.err.println("Błąd podczas odczytu bazy danych!");
            return;
        }

        // 2. Wyznaczenie parametrów statystycznych dla modelu
        computeStats();

        // 3. Konfiguracja logiki rozmytej (Fuzzy Logic)
        FuzzySet[][] fuzzyModel = new FuzzySet[4][3];

        for (int featureIdx = 0; featureIdx < 4; featureIdx++) {
            for (int classIdx = 0; classIdx < 3; classIdx++) {
                FuzzySet set = new FuzzySet();
                // Parametryzacja funkcji Gaussa: (centrum, odchylenie)
                set.newGaussian(avgMatrix[featureIdx][classIdx], deviationMatrix[featureIdx][classIdx]);
                fuzzyModel[featureIdx][classIdx] = set;
            }
        }

        // Przykład: Testowanie obiektu o indeksie 5
        double[] currentTest = dataSamples.get(5);
        System.out.println("Analizowany wektor cech: " + java.util.Arrays.toString(currentTest));

        // 4. Proces decyzyjny (Klasyfikacja)
        String prediction = performInference(currentTest, fuzzyModel);

        System.out.println("\n--- WERDYKT KOŃCOWY ---");
        System.out.println("Zidentyfikowany gatunek: " + prediction);
    }

    private static boolean readData(String fileName) {
        try (Scanner sc = new Scanner(new File(fileName))) {
            while (sc.hasNextLine()) {
                String row = sc.nextLine();
                if (row.trim().isEmpty()) continue;

                String[] parts = row.split(",");
                double[] attributes = new double[4];

                for (int i = 0; i < 4; i++) {
                    attributes[i] = Double.parseDouble(parts[i]);
                }

                dataSamples.add(attributes);
                dataLabels.add(parts[4].trim());
            }
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    private static void computeStats() {
        for (int c = 0; c < IRIS_TYPES.length; c++) {
            for (int f = 0; f < 4; f++) {
                double totalValue = 0;
                int observations = 0;

                // Etap I: Średnia arytmetyczna
                for (int i = 0; i < dataSamples.size(); i++) {
                    if (dataLabels.get(i).equalsIgnoreCase(IRIS_TYPES[c])) {
                        totalValue += dataSamples.get(i)[f];
                        observations++;
                    }
                }

                double meanVal = totalScore(totalValue, observations);
                avgMatrix[f][c] = meanVal;

                // Etap II: Odchylenie standardowe (Sigma)
                double squareDiffSum = 0;
                for (int i = 0; i < dataSamples.size(); i++) {
                    if (dataLabels.get(i).equalsIgnoreCase(IRIS_TYPES[c])) {
                        squareDiffSum += Math.pow(dataSamples.get(i)[f] - meanVal, 2);
                    }
                }
                deviationMatrix[f][c] = Math.sqrt(squareDiffSum / observations);
            }
        }
    }

    private static double totalScore(double sum, int n) {
        return n == 0 ? 0 : sum / n;
    }

    private static String performInference(double[] input, FuzzySet[][] model) {
        double[] classRank = new double[3];

        System.out.println("\nAnaliza przynależności:");
        for (int c = 0; c < 3; c++) {
            double cumulativeMembership = 0;
            for (int f = 0; f < 4; f++) {
                model[f][c].fuzzyfy(input[f]);
                cumulativeMembership += model[f][c].getMembership(input[f]);
            }
            classRank[c] = cumulativeMembership;
            System.out.printf("%-15s: %.5f%n", IRIS_TYPES[c], classRank[c]);
        }

        // Lokalizacja indeksu o najwyższej wartości
        int winnerIdx = 0;
        for (int i = 1; i < classRank.length; i++) {
            if (classRank[i] > classRank[winnerIdx]) {
                winnerIdx = i;
            }
        }
        return IRIS_TYPES[winnerIdx];
    }
}